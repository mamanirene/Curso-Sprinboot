package com.ejemplo.videojuego;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideojuegoApplicationTests {

	@Test
	void contextLoads() {
	}

}
