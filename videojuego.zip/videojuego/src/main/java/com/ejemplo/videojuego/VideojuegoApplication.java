package com.ejemplo.videojuego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideojuegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideojuegoApplication.class, args);
	}

}
